export const ADD_EVENT = "ADD_EVENT"
export const DELETE_EVENT = "DELETE_EVENT" 