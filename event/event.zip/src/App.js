import { useState } from 'react';
import './App.css';
import { Button } from "reactstrap"
import 'bootstrap/dist/css/bootstrap.min.css';

import EventsList from './Components/EventsList';
import EventModel from './Components/Model/EventModel';

const App = () => {
  const [isModelOpen, setIsModelOpen] = useState(false)
  return (
    <>
    <div className="App">
      <header className="App-header">
        <Button color='primary' onClick={() => setIsModelOpen(!isModelOpen)}>Add Event</Button>
        <EventsList />
      </header>
    </div>

    {isModelOpen && <EventModel isOpen={isModelOpen} toggle={() => setIsModelOpen(!isModelOpen)} />}
    </>
  );
}

export default App;
